<?php if (!defined('THINK_PATH')) exit(); /*a:4:{s:63:"D:\phpStudy\WWW\sias001/application/index\view\index\index.html";i:1542112053;s:65:"D:\phpStudy\WWW\sias001\application\index\view\public\header.html";i:1542106790;s:62:"D:\phpStudy\WWW\sias001\application\index\view\public\nav.html";i:1542103460;s:65:"D:\phpStudy\WWW\sias001\application\index\view\public\footer.html";i:1542103001;}*/ ?>
<!DOCTYPE html>
<html lang="zh-CN">
<head>
    <meta charset="utf-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <meta name="keywords" content="西亚斯集团-关键字">
    <meta name="description" content="西亚斯集团-描述">
    <!-- 上述3个meta标签*必须*放在最前面，任何其他内容都*必须*跟随其后！ -->
    <title>西亚斯集团-标题</title>

    <!-- Bootstrap -->
<!--<link href="/boot/font-awesome/css/font-awesome.min.css" rel="stylesheet">-->
<link href="/style/css/bootstrap.min.css" rel="stylesheet">

<link rel="stylesheet" type="text/css" href="/style/boot/css/bootsnav.css">
<link rel="stylesheet" href="/style/css/main.css">
<link rel="stylesheet" href="/style/css/main_0_768.css">
<link rel="stylesheet" href="/style/css/main_768.css">

<link rel="stylesheet" href="/style/css/main_768_992.css">
<link rel="stylesheet" href="/style/css/main_992_1200.css">

<link rel="stylesheet" href="/style/css/main_992.css">
<link rel="stylesheet" href="/style/css/main_1200.css">




<link rel="stylesheet" href="/style/css/animate.min.css">


<!-- HTML5 shim 和 Respond.js 是为了让 IE8 支持 HTML5 元素和媒体查询（media queries）功能 -->
<!-- 警告：通过 file:// 协议（就是直接将 html 页面拖拽到浏览器中）访问页面时 Respond.js 不起作用 -->
<!--[if lt IE 9]>
<script src="https://cdn.jsdelivr.net/npm/html5shiv@3.7.3/dist/html5shiv.min.js"></script>
<script src="https://cdn.jsdelivr.net/npm/respond.js@1.4.2/dest/respond.min.js"></script>
<![endif]-->

</head>
<body>

<div class="container-fluid container-fluid_nav">
    <div class="container">
        <div class="row">


            <div class="col-md-12">
                <nav class="navbar navbar-default navbar-mobile bootsnav">
                    <div class="navbar-header">
                        <button type="button" class="navbar-toggle" data-toggle="collapse" data-target="#navbar-menu">
                            <i class=" nav-icon glyphicon glyphicon-align-justify"></i>
                        </button>
                    </div>
                    <div class="index-logo" style="">
                        <img src="/style/images/index_logo.png" alt="">
                    </div>


                    <div class="collapse navbar-collapse" id="navbar-menu">
                        <ul class="nav navbar-nav" data-in="fadeInLeft" >
                            <li><a href="/" class="fs-20">首页</a></li>
                            <li class="dropdown">
                                <a href="#" class="dropdown-toggle" data-toggle="dropdown">关于我们</a>
                                <ul class="dropdown-menu">
                                    <li><a href="/about/introduction" class="index-ch">集团简介</a></li>
                                    <li><a href="dszjs.html" class="index-ch">董事长介绍</a></li>
                                    <li><a href="qywh.html" class="index-ch">企业文化</a></li>

                                </ul>
                            </li>
                            <li class="dropdown">
                                <a href="#" class="dropdown-toggle" data-toggle="dropdown">集团业务</a>
                                <ul class="dropdown-menu">
                                    <li><a href="jiaoyu.html" class="index-ch">教育板块</a></li>
                                    <li><a href="keji.html" class="index-ch">科技板块</a></li>
                                    <li><a href="shiye.html" class="index-ch">实业板块</a></li>

                                </ul>
                            </li>
                            <li class="dropdown">
                                <a href="#" class="dropdown-toggle" data-toggle="dropdown">新闻中心</a>
                                <ul class="dropdown-menu">
                                    <li><a href="news.html" class="index-ch">集团新闻</a></li>
                                    <li><a href="news.html" class="index-ch">教育新闻</a></li>
                                    <li><a href="news.html" class="index-ch">科技新闻</a></li>
                                    <li><a href="news.html" class="index-ch">实业新闻</a></li>

                                </ul>
                            </li>
                            <li class="dropdown">
                                <a href="#" class="dropdown-toggle" data-toggle="dropdown">联系我们</a>
                                <ul class="dropdown-menu">
                                    <li><a href="join.html" class="index-ch">加入我们</a></li>
                                    <li><a href="contact.html" class="index-ch">联系我们</a></li>

                                </ul>
                            </li>
                        </ul>
                    </div>
                </nav>
            </div>


        </div>
    </div>
</div>


<div class="container-fluid">

</div>

<div id="carousel-example-generic" class="carousel slide" data-ride="carousel">
    <!-- Indicators -->
    <ol class="carousel-indicators">
        <li data-target="#carousel-example-generic" data-slide-to="0" class="active"></li>
        <li data-target="#carousel-example-generic" data-slide-to="1"></li>
        <li data-target="#carousel-example-generic" data-slide-to="2"></li>
    </ol>

    <!-- Wrapper for slides -->
    <div class="carousel-inner" role="listbox">
        <?php if(is_array($loop['banner']) || $loop['banner'] instanceof \think\Collection || $loop['banner'] instanceof \think\Paginator): $i = 0; $__LIST__ = $loop['banner'];if( count($__LIST__)==0 ) : echo "" ;else: foreach($__LIST__ as $key=>$banner): $mod = ($i % 2 );++$i;?>
        <div class="item <?php echo $banner['other_class']; ?> banner_add">
            <img src="<?php echo $banner['img']; ?>" alt="<?php echo $banner['title']; ?>">
            <div class="carousel-caption">
                <h1 class="fb"><?php echo $banner['title']; ?></h1>
                <h2  class="fb"><?php echo $banner['subtitle']; ?></h2>
            </div>
        </div>
        <?php endforeach; endif; else: echo "" ;endif; ?>
    </div>

    <!-- Controls -->
    <a class="left carousel-control" href="#carousel-example-generic" role="button" data-slide="prev">
        <span class="glyphicon glyphicon-chevron-left" aria-hidden="true"></span>
        <span class="sr-only">Previous</span>
    </a>
    <a class="right carousel-control" href="#carousel-example-generic" role="button" data-slide="next">
        <span class="glyphicon glyphicon-chevron-right" aria-hidden="true"></span>
        <span class="sr-only">Next</span>
    </a>
</div>


<div class="container-fluid bg—ff ">
    <div class="divtest animated animation-delay-2 " data-animation="fadeInUp">

        <h1 class="first_title">
            <?php echo $column['siasnews']['title']; ?>
        </h1>
    </div>
</div>


<div class="container-fluid index-xinwen">
    <div class="container divtest animated animation-delay-2 " data-animation="fadeIn">

    <h3 class="fb index-xinwen-title"><?php echo $loop['siasnews']['0']['title']; ?></h3>
        <div class="col-xs-12 col-md-6 index_xinwen_left ">
            <p class="index-xinwen-con">
                <?php echo $loop['siasnews']['0']['content']; ?>
            </p>
            <div class="col-xs-12 index_xinwen_left_img_bo">
                <?php if(is_array($loop['siasnews']) || $loop['siasnews'] instanceof \think\Collection || $loop['siasnews'] instanceof \think\Paginator): $i = 0; $__LIST__ = $loop['siasnews'];if( count($__LIST__)==0 ) : echo "" ;else: foreach($__LIST__ as $key=>$siasnews): $mod = ($i % 2 );++$i;?>
                <div class="col-xs-3 index_xinwen_left_img change-xinwen <?php echo $siasnews['other_class']; ?>" data-title="<?php echo $siasnews['title']; ?>"
                     data-con="<?php echo $siasnews['content']; ?>"
                     data-img="<?php echo $siasnews['img']; ?>">
                    <img src="<?php echo $siasnews['other']; ?>" alt="">
                </div>
                <?php endforeach; endif; else: echo "" ;endif; ?>
            </div>
        </div>

        <div class="col-xs-12 col-md-6 index_xinwen_right">
            <img src="/style/images/xinwen_logo.jpg" class="index-xinwen-img" alt="西亚斯集团">
        </div>
    </div>
</div>


<div class="container-fluid">
    <div class="container divtest animated animation-delay-2 " data-animation="fadeInUp">

    <h1 class="first_title">
        <?php echo $column['jtbk']['title']; ?>
        </h1>
    </div>
</div>


<div class="container-fluid index-bankuai">
    <div class="container divtest animated animation-delay-2 " data-animation="fadeIn">


    <div class="row ">
        <?php if(is_array($loop['jtbk']) || $loop['jtbk'] instanceof \think\Collection || $loop['jtbk'] instanceof \think\Paginator): $i = 0; $__LIST__ = $loop['jtbk'];if( count($__LIST__)==0 ) : echo "" ;else: foreach($__LIST__ as $key=>$jtbk): $mod = ($i % 2 );++$i;?>
            <div class="col-xs-12 col-md-4  index-bankuai—list ">
                <div class="thumbnail pnp__card-shadow">
                    <img src="<?php echo $jtbk['img']; ?>" width="150" alt="...">
                    <div class="caption">
                        <h3 class="fb"><?php echo $jtbk['title']; ?></h3>

                        <p>
                            <?php echo $jtbk['subtitle']; ?>

                        </p>
                        <button class=" fb  bankuai_btn <?php echo $jtbk['other_class']; ?> ">
                            进入<?php echo $jtbk['title']; ?>
                        </button>
                    </div>
                </div>
            </div>
        <?php endforeach; endif; else: echo "" ;endif; ?>

        </div>
    </div>
</div>


<div class=" container-fluid index-xiangmu">


    <div class=" bg—ff ">
        <div class="container divtest animated animation-delay-2 " data-animation="fadeInUp">

        <h1 class="first_title">
            <?php echo $column['jtxm']['title']; ?>
            </h1>
        </div>
    </div>

    <div class="container-fluid index-xiangmu-body ">
        <div class="container divtest animated animation-delay-2 " data-animation="fadeIn">


            <?php if(is_array($loop['jtxm']) || $loop['jtxm'] instanceof \think\Collection || $loop['jtxm'] instanceof \think\Paginator): $i = 0; $__LIST__ = $loop['jtxm'];if( count($__LIST__)==0 ) : echo "" ;else: foreach($__LIST__ as $key=>$jtxm): $mod = ($i % 2 );++$i;?>
                <div class="col-xs-6  col-md-3 index-list index-xiangmu_bh index-xiangmu_rh ">
                <img src="<?php echo $jtxm['img']; ?>" alt="<?php echo $jtxm['title']; ?>">

                <div class="index-xiangmu_mb col-xs-12">
                    <a href="#">
                        <p>
                            <i class="glyphicon glyphicon-search"></i>
                        </p>
                        <p>
                            <?php echo $jtxm['title']; ?>
                        </p>
                    </a>

                </div>
            </div>
            <?php endforeach; endif; else: echo "" ;endif; ?>


        </div>
    </div>

</div>

<footer class="container-fluid footer">
    <div class="container divtest animated animation-delay-2 " data-animation="fadeIn">

        <div class="col-xs-12 col-md-3">
            <img src="/style/images/footer_logo.png" alt="">
        </div>
        <div class="col-xs-12 col-md-3 footer-list">
            <h3>关于我们</h3>
            <p>
                <a href="#">集团简介</a>
            </p>
            <p>
                <a href="#">企业文化</a>
            </p>
            <p>
                <a href="#">加入我们</a>
            </p>

        </div>
        <div class="col-xs-12 col-md-3 footer-list">
            <h3>集团项目</h3>
            <p>
                <a href="#">教育板块</a>
            </p>
            <p>
                <a href="#">科技板块</a>
            </p>
            <p>
                <a href="#">事业板块</a>
            </p>

        </div>
        <div class="col-xs-12 col-md-3 footer-list">
            <h3>联系我们</h3>
            <p>
                地址：西亚斯学院三号别墅
            </p>
            <p>
                电话：0370-12345678
            </p>
            <p>
                邮箱：info@sias.cn
            </p>
            <p>
                微信：西亚斯集团
            </p>
        </div>


    </div>

    <div class="container footer_bottom" style="">
        <span>西亚斯集团版权所有 ©2018</span>

        <a href="#">
            法律声明
        </a>
    </div>
</footer>


<!-- jQuery (Bootstrap 的所有 JavaScript 插件都依赖 jQuery，所以必须放在前边) -->
<script src="/style/js/jquery.js"></script>
<!-- 加载 Bootstrap 的所有 JavaScript 插件。你也可以根据需要只加载单个插件。 -->
<script src="/style/js/bootstrap.min.js"></script>
<script type="text/javascript" src="/style/boot/js/bootsnav.js"></script>
<script type="text/javascript" src="/style/boot/js/bootsnav.js"></script>
<script src="/style/js/main.js"></script>
<script src="/style/js/isScroll.js"></script>



<script type="text/javascript">
    $(document).ready(function () {
        isScroll.init('.divtest');

        $(document).scroll(function () {
            if ($(document).scrollTop() > 600) {
                $('.add-top-banner').addClass('add-top-banner-bg');

            } else {
                $('.add-top-banner').removeClass('add-top-banner-bg');
            }
            ;
            $('.add-rem-animated').removeClass('animated');
        });


    });

</script>

</body>
</html>