<?php if (!defined('THINK_PATH')) exit(); /*a:3:{s:70:"D:\phpStudy\WWW\sias001/application/index\view\index\introduction.html";i:1542114655;s:62:"D:\phpStudy\WWW\sias001\application\index\view\public\nav.html";i:1542103460;s:65:"D:\phpStudy\WWW\sias001\application\index\view\public\footer.html";i:1542103001;}*/ ?>
<!DOCTYPE html>
<html lang="zh-CN">
<head>
    <meta charset="utf-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <meta name="keywords" content="西亚斯集团-关键字">
    <meta name="description" content="西亚斯集团-描述">
    <!-- 上述3个meta标签*必须*放在最前面，任何其他内容都*必须*跟随其后！ -->
    <title>西亚斯集团-标题</title>

    <link href="/style/css/bootstrap.min.css" rel="stylesheet">


    <link rel="stylesheet" type="text/css" href="/style/boot/css/bootsnav.css">     <link rel="stylesheet" href="/style/css/main.css">
    <link rel="stylesheet" href="/style/css/main_0_768.css">
    <link rel="stylesheet" href="/style/css/main_768.css">

    <link rel="stylesheet" href="/style/css/main_768_992.css">
    <link rel="stylesheet" href="/style/css/main_992_1200.css">

    <link rel="stylesheet" href="/style/css/main_992.css">
    <link rel="stylesheet" href="/style/css/main_1200.css">

    <link rel="stylesheet" href="/style/css/timeline.css" />

    <!-- HTML5 shim 和 Respond.js 是为了让 IE8 支持 HTML5 元素和媒体查询（media queries）功能 -->
    <!-- 警告：通过 file:// 协议（就是直接将 html 页面拖拽到浏览器中）访问页面时 Respond.js 不起作用 -->
    <!--[if lt IE 9]>
    <script src="https://cdn.jsdelivr.net/npm/html5shiv@3.7.3/dist/html5shiv.min.js"></script>
    <script src="https://cdn.jsdelivr.net/npm/respond.js@1.4.2/dest/respond.min.js"></script>
    <![endif]-->
</head>
<body>


<div class="container-fluid container-fluid_nav">
    <div class="container">
        <div class="row">


            <div class="col-md-12">
                <nav class="navbar navbar-default navbar-mobile bootsnav">
                    <div class="navbar-header">
                        <button type="button" class="navbar-toggle" data-toggle="collapse" data-target="#navbar-menu">
                            <i class=" nav-icon glyphicon glyphicon-align-justify"></i>
                        </button>
                    </div>
                    <div class="index-logo" style="">
                        <img src="/style/images/index_logo.png" alt="">
                    </div>


                    <div class="collapse navbar-collapse" id="navbar-menu">
                        <ul class="nav navbar-nav" data-in="fadeInLeft" >
                            <li><a href="/" class="fs-20">首页</a></li>
                            <li class="dropdown">
                                <a href="#" class="dropdown-toggle" data-toggle="dropdown">关于我们</a>
                                <ul class="dropdown-menu">
                                    <li><a href="/about/introduction" class="index-ch">集团简介</a></li>
                                    <li><a href="dszjs.html" class="index-ch">董事长介绍</a></li>
                                    <li><a href="qywh.html" class="index-ch">企业文化</a></li>

                                </ul>
                            </li>
                            <li class="dropdown">
                                <a href="#" class="dropdown-toggle" data-toggle="dropdown">集团业务</a>
                                <ul class="dropdown-menu">
                                    <li><a href="jiaoyu.html" class="index-ch">教育板块</a></li>
                                    <li><a href="keji.html" class="index-ch">科技板块</a></li>
                                    <li><a href="shiye.html" class="index-ch">实业板块</a></li>

                                </ul>
                            </li>
                            <li class="dropdown">
                                <a href="#" class="dropdown-toggle" data-toggle="dropdown">新闻中心</a>
                                <ul class="dropdown-menu">
                                    <li><a href="news.html" class="index-ch">集团新闻</a></li>
                                    <li><a href="news.html" class="index-ch">教育新闻</a></li>
                                    <li><a href="news.html" class="index-ch">科技新闻</a></li>
                                    <li><a href="news.html" class="index-ch">实业新闻</a></li>

                                </ul>
                            </li>
                            <li class="dropdown">
                                <a href="#" class="dropdown-toggle" data-toggle="dropdown">联系我们</a>
                                <ul class="dropdown-menu">
                                    <li><a href="join.html" class="index-ch">加入我们</a></li>
                                    <li><a href="contact.html" class="index-ch">联系我们</a></li>

                                </ul>
                            </li>
                        </ul>
                    </div>
                </nav>
            </div>


        </div>
    </div>
</div>



<div class="container-fluid jtjj-banner">
    <div class="container jtjj-banner-title">
        <h1 class="fb">集团简介</h1>
    </div>

</div>


<div class="container-fluid jtjj-slide2 bg—ff">
    <div class="container">
        <div class="col-xs-12 col-md-6">
            <img src="<?php echo $module['jtjs']['img']; ?>" alt="">
        </div>
        <div class="col-xs-12 col-md-6">
            <h3 class="fb"><?php echo $module['jtjs']['title']; ?></h3>
            <p>
                <?php echo $module['jtjs']['content']; ?>
            </p>

        </div>
    </div>

</div>

<div class="container-fluid  ">
    <div class="container">
        <h1 class="first_title">
            <?php echo $column['dsj']['title']; ?>
        </h1>
    </div>
</div>


<div class="container-fluid  jtjj-slide3">
    <div class="container ">


        <section id="cd-timeline" class="cd-container">
            <?php if(is_array($loop['dsj']) || $loop['dsj'] instanceof \think\Collection || $loop['dsj'] instanceof \think\Paginator): $i = 0; $__LIST__ = $loop['dsj'];if( count($__LIST__)==0 ) : echo "" ;else: foreach($__LIST__ as $key=>$dsj): $mod = ($i % 2 );++$i;?>
            <div class="cd-timeline-block">
                <div class="cd-timeline-img <?php echo $dsj['other_class']; ?>">
                    <img src="<?php echo $dsj['img']; ?>" alt="Picture">
                </div>

                <div class="cd-timeline-content">
                    <h2><?php echo $dsj['title']; ?></h2>
                    <p><?php echo $dsj['content']; ?></p>
                    <a href="#" class="cd-read-more" target="_blank">阅读全文</a>
                    <span class="cd-date"><?php echo $dsj['subtitle']; ?></span>
                </div>
            </div>
            <?php endforeach; endif; else: echo "" ;endif; ?>

        </section>

    </div>



</div>

<footer class="container-fluid footer">
    <div class="container divtest animated animation-delay-2 " data-animation="fadeIn">

        <div class="col-xs-12 col-md-3">
            <img src="/style/images/footer_logo.png" alt="">
        </div>
        <div class="col-xs-12 col-md-3 footer-list">
            <h3>关于我们</h3>
            <p>
                <a href="#">集团简介</a>
            </p>
            <p>
                <a href="#">企业文化</a>
            </p>
            <p>
                <a href="#">加入我们</a>
            </p>

        </div>
        <div class="col-xs-12 col-md-3 footer-list">
            <h3>集团项目</h3>
            <p>
                <a href="#">教育板块</a>
            </p>
            <p>
                <a href="#">科技板块</a>
            </p>
            <p>
                <a href="#">事业板块</a>
            </p>

        </div>
        <div class="col-xs-12 col-md-3 footer-list">
            <h3>联系我们</h3>
            <p>
                地址：西亚斯学院三号别墅
            </p>
            <p>
                电话：0370-12345678
            </p>
            <p>
                邮箱：info@sias.cn
            </p>
            <p>
                微信：西亚斯集团
            </p>
        </div>


    </div>

    <div class="container footer_bottom" style="">
        <span>西亚斯集团版权所有 ©2018</span>

        <a href="#">
            法律声明
        </a>
    </div>
</footer>


<!-- jQuery (Bootstrap 的所有 JavaScript 插件都依赖 jQuery，所以必须放在前边) -->
<script src="/style/js/jquery.js"></script>
<!-- 加载 Bootstrap 的所有 JavaScript 插件。你也可以根据需要只加载单个插件。 -->
<script src="/style/js/bootstrap.min.js"></script>
<script type="text/javascript" src="/style/boot/js/bootsnav.js"></script>
<script type="text/javascript" src="/style/boot/js/bootsnav.js"></script>
<script src="/style/js/main.js"></script>
<script src="/style/js/isScroll.js"></script>
</body>
</html>