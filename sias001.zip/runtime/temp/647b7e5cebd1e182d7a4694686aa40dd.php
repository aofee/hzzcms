<?php if (!defined('THINK_PATH')) exit(); /*a:2:{s:69:"D:\phpStudy\WWW\sias001/application/admin\view\index\column_list.html";i:1542166204;s:63:"D:\phpStudy\WWW\sias001\application\admin\view\public\meta.html";i:1541838220;}*/ ?>
<!DOCTYPE html>
<html>
	<head>
		<meta charset="UTF-8">
		<title>文章分类-WeAdmin Frame型后台管理系统-WeAdmin 1.0</title>
		<meta name="renderer" content="webkit|ie-comp|ie-stand">
<meta http-equiv="X-UA-Compatible" content="IE=edge,chrome=1">
<meta name="viewport" content="width=device-width, initial-scale=1.0, minimum-scale=1.0, maximum-scale=1.0, user-scalable=0">
<meta http-equiv="Cache-Control" content="no-siteapp" />
<link rel="shortcut icon" href="./favicon.ico" type="image/x-icon" />
<link rel="stylesheet" href="/public/static/css/font.css">
<link rel="stylesheet" href="/public/static/css/weadmin.css">
<script type="text/javascript" src="/public/lib/layui/layui.js" charset="utf-8"></script>
		<!-- 让IE8/9支持媒体查询，从而兼容栅格 -->
		<!--[if lt IE 9]>
	      <script src="https://cdn.staticfile.org/html5shiv/r29/html5.min.js"></script>
	      <script src="https://cdn.staticfile.org/respond.js/1.4.2/respond.min.js"></script>
	    <![endif]-->
	</head>

	<body>
		<div class="weadmin-nav">
			<span class="layui-breadcrumb">
		        <a href="">首页</a>
		        <a href="">栏目管理</a>
		        <a><cite>栏目列表</cite></a>
		    </span>
			<a class="layui-btn layui-btn-sm" style="line-height:1.6em;margin-top:3px;float:right" href="javascript:location.replace(location.href);" title="刷新">
				<i class="layui-icon" style="line-height:30px">ဂ</i></a>
		</div>
		<div class="weadmin-body">
			<div class="weadmin-block">
				<button class="layui-btn" id="expand">全部展开</button>
				<button class="layui-btn" id="collapse">全部收起</button>
				<button class="layui-btn" onclick="WeAdminShow('添加分类','./category-add.html')"><i class="layui-icon"></i>添加</button>
				<span class="fr" style="line-height:40px">共有数据：66 条</span>
			</div>

			<div id="demo" class="layui-tree">
				<div class="layui-form">
					<table class="layui-table">
						<thead>
						<tr>
							<th>

							</th>
							<th class="value_col">菜单名称</th>
							<th class="td-status">状态</th>
							<th class="td-manage">操作</th>
						</tr>
						</thead>
						<tbody>
						<tr class="" id="1"><td style="width:20%">1</td><td class="value_col" style="width: 60%"><li data-spread="true"><i class="layui-icon layui-tree-spread"></i><a href="javascript:;"><i class="layui-icon layui-tree-branch"></i><cite>父节点1</cite></a></li></td><td class="td-status" style="width: 10%"><span class="layui-btn layui-btn-normal layui-btn-xs">已启用</span></td><td class="td-manage" style="width: 20%"><a onclick="member_stop(this,'10001')" href="javascript:;" title="启用"><i class="layui-icon"></i></a><a title="添加子类" onclick="WeAdminShow('添加','./category-add.html')" href="javascript:;"><i class="layui-icon"></i></a><a title="编辑" onclick="WeAdminShow('编辑','./category-edit.html')" href="javascript:;"><i class="layui-icon"></i></a><a title="删除" onclick="del(1)" href="javascript:;"><i class="layui-icon"></i></a></td></tr>
						</tbody>
					</table>
				</div>
			</div>
		</div>
		<script src="/public/lib/layui/layui.js" charset="utf-8"></script>
		<script src="/public/static/js/category.js" type="text/javascript" charset="utf-8"></script>
	</body>

</html>